import requests
import subprocess
import time
class Executor:
    def __init__(self):
        self.base_url = "http://instagram.ece750cluster-04e8c71ff333c8969bc4cbc5a77a70f6-0000.ca-tor.containers.appdomain.cloud/"

    def set_image_quantity(self, quantity):
        url = self.base_url + "user/setLoadingNumber"
        data = {"loadingNumber": quantity}
        response = requests.post(url, data=data)

        if response.status_code == 200:  # Assuming a successful creation status code
            # print('POST request was successful!')
            # print('Response content:', response.text)
            return True
        else:
            # print('Error:', response.status_code)
            return False
        

    def set_image_quality(self, quality):
        url = self.base_url + "post/resolution"
        image_quality = "high" if quality else "low"
        data = {"resolution": image_quality}
        response = requests.post(url, json=data)

        if response.status_code == 200:  # Assuming a successful creation status code
            # print('POST request was successful!')
            # print('Response content:', response.text)
            return True
        else:
            # print('Error:', response.status_code)
            return False

    # Function to fetch data from IBM Cloud
    def execute(self, adaptation_plans, configurations):
        # Check if the adaptation options are valid
        # If valid, return True
        # Otherwise, return False
        for idx, adaptation_plan in enumerate(adaptation_plans):
            if adaptation_plan:
                cpu = adaptation_plan["cpu"]
                memory = adaptation_plan["memory"]
                replica = adaptation_plan['replica']
                service = adaptation_plan['service']
                command = f"./config.sh cpu={cpu} memory={memory} replica={replica} service={service}"
                res = subprocess.run(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                if res.returncode != 0:
                    print("Adaptation failed with error:")
                    print(res.stderr)
                    return
                    
        print("Waiting for one minutes for container creation or deletion...")
        time.sleep(60)
        for idx, adaptation_plan in enumerate(adaptation_plans):
            if adaptation_plan:
                cpu = adaptation_plan["cpu"]
                memory = adaptation_plan["memory"]
                replica = adaptation_plan['replica']
                quantity = adaptation_plan['quantity']
                quality = adaptation_plan['quality']
                service = adaptation_plan['service']

                res1 = True
                res2 = True

                if service == "backend-user":
                    for _ in range(100):
                        res1 = res1 and self.set_image_quantity(quantity)
                if service == "backend-post":    
                    for _ in range(100):
                        res2 = res2 and self.set_image_quality(quality)

                # Check the result
                if res1 and res2:
                    if quantity != configurations[idx]['quantity']:
                        print(f"Image loading quantity is changed from {configurations[idx]['quantity']} to {quantity} for {service}")
                    elif quality != configurations[idx]['quality']:
                        new_image_quality = "high" if quality else "low"
                        old_image_quality = "high" if configurations[idx]['quality'] else "low"
                        print(f"Image quality is changed from {old_image_quality} to {new_image_quality} for {service}")
                    elif replica != configurations[idx]['replica']:
                        print(f"Replica is changed from {configurations[idx]['replica']} to {replica} for {service}")
                    configurations[idx] = adaptation_plan
                else:
                    print("Adaptation failed with error")
