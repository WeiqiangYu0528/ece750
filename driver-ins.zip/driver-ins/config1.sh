#!/bin/bash

# Get the list of pods
pods=$(kubectl get pods -o=name)

# Set the HTTP endpoint you want to hit
endpoint="http://your-service-name:your-port/your-path"

# Iterate over each pod and send an HTTP request
for pod in $pods; do
    pod_ip=$(kubectl get $pod -o=jsonpath='{.status.podIP}')
    echo "Sending HTTP request to pod: $pod, IP: $pod_ip"
    curl -X GET $pod_ip:8080/home/alex
done