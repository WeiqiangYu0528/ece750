import json
import numpy as np
import pandas as pd

class Analyzer:
    def __init__(self, metrics):
        # set relative weight for each property
        self.weight_cpu = 0.2
        self.weight_memory = 0.2
        self.weight_latency = 0.45
        self.weight_cost = 0.15
        self.metrics = metrics
        self.high_quality = True
        self.quantity_lower_bound = 9
        self.quantity_upper_bound = 18
        self.replica_lower_bound = 1
        self.replica_upper_bound = 5
        # self.configuration_data = self.load_configuration_data()
        self.loads = ["low", "medium", "high"]
        self.services = ['backend-auth', 'backend-post', 'backend-user']
        #self.services = ['acmeair-bookingservice', 'acmeair-customerservice', 'acmeair-flightservice']


    # def load_configuration_data(self):
    #     # Load the configuration data from the configuration file
    #     with open("configuration.json", "r") as file:
    #         data = json.load(file)
    #     return data

    def triggerAdaptation(self, cpu, memory, latency):
        # Check whether adaptation is needed based on CPU, memory, and latency values
        print(f"CPU: {cpu:.2f}, memory: {memory:.2f}, latency: {latency:.2f}")
        if cpu > 75 or memory > 75 or latency > 7e6:
            return (True, True)
        elif cpu < 25 or memory < 25:
            return (True, False)
        return (False, False)
    
    def utility_preference_cpu(self, cpu):
        # Determine the utility preference for CPU usage
        if cpu < 25:
            return 1
        elif cpu < 75:
            return 0.5
        else:
            return 0

    def utility_preference_memory(self, memory):
        # Determine the utility preference for memory usage
        if memory < 25:
            return 1
        elif memory < 75:
            return 0.5
        else:
            return 0
    
    def utility_preference_latency(self, latency):
        # Determine the utility preference for latency
        if latency < 3.5e6:
            return 1
        elif latency < 7e6:
            return 0.5
        else:
            return 0
    
    def utility_preference_cost(self, cost):
        # Determine the utility preference for cost (cpu, memory, pod)
        if cost == "quantity":
            return 1
        elif cost == "quality":
            return 0.5
        else:
            return 0.25

    def calculate_utility(self, cpu_usage, memory_usage, latency, cost):
        # Calculate the overall utility score based on weighted preferences
        cpu_utility = self.weight_cpu * self.utility_preference_cpu(cpu_usage)
        memory_utility = self.weight_memory * self.utility_preference_memory(memory_usage)
        latency_utility = self.weight_latency * self.utility_preference_latency(latency)
        cost_utility = self.weight_cost * self.utility_preference_cost(cost)
        return cpu_utility + memory_utility + latency_utility + cost_utility

    def determine_request_load(self, service):
        filename = "datasets/net_request_count_in_sum_metric.json"
        df = self.create_dataframe(filename)
        aggregationData = df.groupby('service')
        avg_values = aggregationData['value'].mean()
        load = "low"
        if avg_values.loc[service] > 50:
            load = self.loads[2]
        elif avg_values.loc[service] > 10:
            load = self.loads[1]
        print(f"request number for {service} is {avg_values.loc[service]}, {load} traffic")
        return load

    def create_dataframe(self, filename):
        # Create a DataFrame from a JSON file
        with open(filename, 'r') as file:
            data = json.load(file)
        new_data = []
        for entry in data["data"]:
            new_entry = {}
            new_entry["timestamp"] = entry['t']
            new_entry["service"] = entry['d'][0]
            new_entry["value"] = entry['d'][1]
            new_data.append(new_entry)
        return pd.DataFrame(new_data)

    def process_data(self, current_configurations):
        # perform data preprocessing and check whether adaptation is required
        adaptation_options = [None for _ in range(3)]
        outputs = [[0]*len(self.metrics) for _ in range(3)]
        for idx, (metric_id, aggregation) in enumerate(self.metrics):
            filename = "datasets/" + metric_id + "_" + aggregation + "_metric.json"
            df = self.create_dataframe(filename)
            aggregationData = df.groupby('service')
            avg_values = aggregationData['value'].mean()
            # print(avg_values)
            for i in range(3):
                outputs[i][idx] = avg_values.loc[self.services[i]]
        # print(outputs)
        # for each service, determine whether adaptation is needed
        for i in range(3):
            cpu = outputs[i][0]
            memory = outputs[i][1]
            latency = outputs[i][2]
            adaptation, busy = self.triggerAdaptation(cpu, memory, latency)
            if adaptation:
                print(f"{self.services[i]} requires adaptation")
                adaptation_options[i] = self.generate_adaptation_options(current_configurations[i], self.services[i], busy)
            else:
                print(f"No adaptation required for {self.services[i]}")
        return adaptation_options
    
    # def fetch_configuration_data(self, option):
    #     if self.check_validity(option):
    #     #if True:
    #         img_quality = "high" if option['quality'] else "low"
    #         key = f"{option['service']}_{option['replica']}_{option['quantity']}_{option['load']}_{img_quality}"
    #         if self.configuration_data.get(key):
    #             return self.configuration_data[key]
    #         else:
    #             print(f"Key {key} is invalid")
    #     return None
    
    def predict_service(self, option, weights, bias, type):
        if option['service'] == "backend-auth":
            s1, s2, s3 = 1, 0, 0
        elif option['service'] == "backend-post":
            s1, s2, s3 = 0, 1, 0
        else:
            s1, s2, s3 = 0, 0, 1
        if option['quality']:
            q1, q2 = 1, 0
        else:
            q1, q2 = 0, 1
        if option['load'] == "high":
            l1, l2, l3 = 1, 0, 0
        elif option['load'] == "medium":
            l1, l2, l3 = 0, 1, 0
        else:
            l1, l2, l3 = 0, 0, 1
        cpu = option['cpu']
        memory = option['memory']
        replica = option['replica']
        quantity = option['quantity']
        
        prediction = weights[0] * s1 + weights[1] * s2 + weights[2] * s3 +  weights[3] * cpu + weights[4] * memory + weights[5] * replica + weights[6] * quantity + weights[7] * q1 + weights[8] * q2 + weights[9] * l1 + weights[10] * l2 + weights[11] * l3 + bias
        normalized_prediction =  1 / (1 + np.exp(-prediction)) * np.random.rand()
        if type == "cpu" or type == "memory":
            return normalized_prediction * 100
        return normalized_prediction * 7e6

    def predict(self, option, cost):
        if self.check_validity(option, cost):
            data = {}
            cpu_usage_weights = [0.16270995, 0.90780162, 0.40740702, 0.83308008, 0.67702882, 0.82656679, 0.16249774,
            0.22601816, 0.1390844 , 0.03522276, 0.05193925, 0.88816794]
            cpu_usage_bias = 0.30718502

            memory_usage_weights = [0.09873021, 0.42235236, 0.34973872, 0.22256633, 0.96521462, 0.71134722, 0.08842723,
            0.55227301, 0.437364, 0.67552667, 0.01536254, 0.07057566]
            memory_usage_bias = 0.23898690

            response_time_weights = [0.12566071, 0.66562694, 0.61445523, 0.05539654, 0.26436592, 0.11152285, 0.37182357,
            0.65477654, 0.40156996, 0.94547038, 0.67778606, 0.06966497]
            response_time_bias = 0.06837226

            data['cpu_percent'] = self.predict_service(option, cpu_usage_weights, cpu_usage_bias, "cpu")
            data['memory_percent'] = self.predict_service(option, memory_usage_weights, memory_usage_bias, "memory")
            data['response_time'] = self.predict_service(option, response_time_weights, response_time_bias, "response_time")
            return data
        return None

    def check_validity(self, option, cost):
        # Check if the adaptation options are valid
        # If valid, return True
        # Otherwise, return False
        valid = True
        if option['replica'] < self.replica_lower_bound or option['replica'] > self.replica_upper_bound \
            or option['quantity'] < self.quantity_lower_bound or option['quantity'] > self.quantity_upper_bound \
            or (option['quality'] == self.high_quality and cost == "quality"):
                valid = False
                print(f"invalid option by changing {cost} to: replica {option['replica']}, {option['quantity']}, {option['quality']}")
        return valid

    def generate_adaptation_option(self, cpu, memory, replica, quantity, quality, cost, service, busy, load):
        # Calculate the overall utility score based on weighted preferences
        option = {"cpu": cpu, "memory": memory, "replica": replica, "quantity": quantity, "quality": quality, "service": service, "load": load}
        data = self.predict(option, cost)
        if data:
            option["utility"] = self.calculate_utility(data['cpu_percent'], data['memory_percent'], data['response_time'], cost)
            if busy and cost == "quantity":
                print(f"Adaptation Strategy: decrease image loading quantity to {quantity} for {service}")
            elif busy and cost == "quality":
                image_quality = "high" if quality else "low"
                print(f"Adaptation Strategy: decrease image quality to {image_quality} for {service}")
            elif busy and cost == "replica":
                print(f"Adaptation Strategy: increase replica to {replica} for {service}")
            elif not busy and cost == "quantity":
                print(f"Adaptation Strategy: increase image loading quantity to {quantity} for {service}")
            elif not busy and cost == "quality":
                image_quality = "high" if quality else "low"
                print(f"Adaptation Strategy: increase image quality to {image_quality} for {service}")
            else:
                print(f"Adaptation Strategy: decrease replica to {replica} for {service}")
            return option
        else:
            print("error")
        return None

    def generate_adaptation_options(self, configuration, service, busy):
        # Find the best adaptation strategy based on utility functions
        adaptation_options = [None for _ in range(2)]
      
        cpu = configuration["cpu"]
        memory = configuration["memory"]
        replica = configuration["replica"]
        quantity = configuration["quantity"]
        quality = configuration["quality"]
        self.high_quality = quality
        load = self.determine_request_load(service)
        # load = 0

        if busy:
            # strategy1: increase pod
            adaptation_options[0] = self.generate_adaptation_option(cpu, memory, replica + 1, quantity, quality, "replica", service, busy, load)
            if service == "backend-user":
                # strategy2: decrease image loading quantity
                adaptation_options[1] = self.generate_adaptation_option(cpu, memory, replica, quantity - 9, quality, "quantity", service, busy, load)
            if service == "backend-post":
                # strategy3: decrease image quality
                adaptation_options[1] = self.generate_adaptation_option(cpu, memory, replica, quantity, False, "quality", service, busy, load)

        else:
            # strategy1: decrease pod
            adaptation_options[0] = self.generate_adaptation_option(cpu, memory, replica - 1, quantity, quality, "replica", service, busy, load)
            if service == "backend-user":
                # strategy2: increase image loading quantity
                adaptation_options[1] = self.generate_adaptation_option(cpu, memory, replica, quantity + 9, quality, "quantity", service, busy, load)
            if service == "backend-post":
                # strategy3: increase image quality
                adaptation_options[1] = self.generate_adaptation_option(cpu, memory, replica, quantity, True, "quality", service, busy, load)

        return adaptation_options
