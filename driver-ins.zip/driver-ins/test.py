import requests

def main():

    for _ in range(100):
        base_url = "http://instagram.ece750cluster-04e8c71ff333c8969bc4cbc5a77a70f6-0000.ca-tor.containers.appdomain.cloud/"

        url = base_url + "post/resolution"
        data = {"resolution": "high"}
        response = requests.post(url, json=data)

        if response.status_code == 200:  # Assuming a successful creation status code
            print('POST request was successful!')
            print('Response content:', response.text)
        else:
            print('Error:', response.status_code)

        url = base_url + "user/setLoadingNumber"
        data = {"loadingNumber": 18}
        response = requests.post(url, data=data)

        if response.status_code == 200:  # Assuming a successful creation status code
            print('POST request was successful!')
            print('Response content:', response.text)
        else:
            print('Error:', response.status_code)

if __name__ == "__main__":
    main()
