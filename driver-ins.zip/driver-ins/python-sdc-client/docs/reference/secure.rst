Sysdig Secure
=============

.. automodule:: sdcclient
.. autoclass:: SdSecureClient
   :members:
   :inherited-members:
   :undoc-members:

.. automodule:: sdcclient
.. autoclass:: SdScanningClient
   :members:
   :inherited-members:
   :undoc-members:
